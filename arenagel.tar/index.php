<!doctype html>
<html>
    <head>
        <title>Углеводный гель и изотоник «АРЕНА» Нон-стоп, энергия твоего движения!</title>
        <meta name="keywords" content="бег, гель, изотоник, напиток бег, гель бег, спортивное питание, питание бег, гель арена, изотоник арена">
        <meta name="description" content="Качественное спортивное питание, по доступной цене. Углеводные гели и изотоник в Минске. С ними ты можешь больше!" />
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width">
        <meta name="theme-color" content="red">
        <link href="images/favicon.ico" rel="shortcut icon" type="image/x-icon" />
        <link href="css/style.css" rel="stylesheet" media="all">
        <link href="css/magnific-popup.css" rel="stylesheet" media="all">
        <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
        <script type="text/javascript" src="js/scroll.js"></script>
        <script type="text/javascript" src="js/jquery.form.js"></script>
        <script type="text/javascript" src="js/jquery.validate.js"></script>
        <script type="text/javascript" src="js/jquery.magnific-popup.min.js"></script>
      <script type="text/javascript">
      $('document').ready(function(){
        $('#form').validate(
        { 
          //Правила
          rules:{
            "name":{ required:true, maxlength:40, minlength:2 },
            "email":{ required:true, email:true }
          },
          //Текста предупреждений
          messages:{
            "name":{ required:"Обязательное поле!", 
            maxlength: "Максимальное количество символов 40 единиц!", minlength: "Минимальное количество символов 2" },
            "email":{ required:"Обязательное поле!", email: "Введите действительный e-mail" }
          },
          //Обработчик и отправка данных
          submitHandler: function(form){
            $(form).ajaxSubmit({
              target: '#result', 
              success: function() { 
                $('#FormBox').slideUp('fast'); 
              } 
            }); 
          }
        })
      $('#form-contact').validate(
        { 
          //Правила
          rules:{
            "name":{ required:true, maxlength:40, minlength:2 },
            "email":{ required:true, email:true }
          },
          //Текста предупреждений
          messages:{
            "name":{ required:"Обязательное поле!", 
            maxlength: "Максимальное количество символов 40 единиц!", minlength: "Минимальное количество символов 2" },
            "email":{ required:"Обязательное поле!", email: "Введите действительный e-mail" }
          },
          //Обработчик и отправка данных
          submitHandler: function(form){
            $(form).ajaxSubmit({
              target: '#result2', 
              success: function() { 
                $('#FormBox2').slideUp('fast'); 
              } 
            }); 
          }
        })
      });
</script>
</head>
<body>
<div class="wrapper">
  <header>
  <div class="inner">
    <a href="/"><img src="images/main-logo.jpg" title="Арена, углеводный гель и изотоник"></a>
    <ul class="menu">
        <li><a href="#arenagel_link">Энергетический гель</a></li>
        <li><a href="#about_link">О бренде</a></li>
        <li><a href="#isotonic_link">Изотоник</a></li>
        <li><a href="#contacts_link">Контакты</a></li>
    </ul>
  </div>
  </header>
  <main id="top">
    <div class="inner">
      <p class="main-message">Энергия <span>для тебя</span></p>
      <h4>Ты можешь больше...</h4>
      <div class="message">
      <h1>Углеводный гель и изотоник «АРЕНА» Нон-стоп,</h1><p>для тех, кто никогда не останавливается на достигнутых результатах и хочет улучшить свой тренировочный процеcс.</p>
      </div>
    </div>
  </main>
  <div class="stock">
    <div class="inner">
      <h4>Хотите узнать предложение месяца?</h4>
      <div id="result"></div>
      <div id="FormBox">
        <form id="form" action="php/form_sale.php" method="post">
            <div class="input"><input type="text" name="name" placeholder="Имя" required></div>
            <div class="input"><input type="mail" name="email" placeholder="email" required></div>
            <input class="submit" type="submit" name="submit" value="УЗНАТЬ">
        </form>
      </div>
    </div>
   </div>
   <div class="energy-gel" id="arenagel_link">
    <div class="inner">
    <h2>Откуда берётся энергия?</h2>
      <div class="left">
        <h3>Глюкоза-фруктоза</h3>
        <p>Глюкоза-фруктоза в чистом виде, обеспечивает мгновенное поступление углеводов в кровь. Результат уже чувствуется втечении 2–3-х минут.</p>
      </div>
      <div class="right">
        <h3>Пищевые волокна</h3>
        <p>Очень-очень длинные пищевые волокна, организму требуется окола часа на их расщепление. Обеспечивают организм долговременной энергией.</p>
      </div>
      <div class="left bottom-margin-50">
        <h3>Мальтодекстрин</h3>
        <p>Более длинные углеводы, которые сначала расщепляются, а потом попадают в организм. Эти углеводы работают втечении 30 мин.</p>
      </div>
      <div class="right bottom-margin-50">
        <h3>Витаминный заряд</h3>
        <p>Витамины и минералы, позволяют своевременно компенсировать их потерю во время физических нагрузок.</p>
      </div>
      <a class="button gudvinga-popup" href="test-ajax.html">Подробнее</a>
      <script type="text/javascript">
      $(document).ready(function() {
        $('.gudvinga-popup').magnificPopup({
          type: 'ajax',
          alignTop: true,
          overflowY: 'scroll'
        });   
      });
    </script>
    </div>
   </div>
   <div class="about" id="about_link">
      <div class="inner">
        <h2>О бренде</h2>
        <p>Спортивное питание «Арена Нон-Стоп»  — российская разработка компании ООО «МВ Энеджи».</p>
        <p>Теперь доступна и белорусским атлетам.</p>
        <p>Углеводные гели и изотонические напитки «Арена Нон-Стоп» выпускаются с 2006 года и являются высокоэффективным, сбалансированным и доступным по цене питанием для спортсменов и людей ведущих активный образ жизни.</p>
        <div class="quote">
          <em>Энергетические гели я делал для себя и делал их с любовью</em>
          <p><i>Игорь Ямчук, создатель геля «Арена Нон-Стоп»</i></p>
        </div>
        <p>За эти годы множество спортсменов циклических видов спорта, альпинистов, туристов, военных, работников МЧС оценили эффективность и качество продукции «Арена Нон-Стоп».</p>
        <p>Продукция «Арена Нон-Стоп» производится на специализированном промышленном оборудовании и проходит жёсткий контроль качества. Наш продукт можно назвать французским. Глюкозо-фруктозный сироп, который применяется для приготовления гелей, делается в Ефремове Тульской области, но на французском заводе «Каргилл». Пищевые волокна и мальтодекстрин также производятся на «Каргилле». Из отечественного в нашем геле только яблочное пюре.</p>
        <p>Для производства спортивного питания «Арена Нон-Стоп» используются наиболее качественные компоненты, а состав разработан на основе научных исследований и обратной связи от использующих нашу продукцию спортсменов.</p>
        <p>Убедитесь в этом сами и, уверены, мы с вами станем хорошими друзьями!</p>
      </div>
   </div>
   <div class="isotonic" id="isotonic_link">
      <div class="inner">
        <h2>Изотоник – всплеск энергии!</h2>
        <div class="left">
          <h3>Углеводы</h3>
          <p>75 г/л простых и сложных углеводов, которые обеспечивают энергией в течение физической нагрузки.</p>
        </div>
        <div class="right">
          <h3>Оптимальный вкус</h3>
          <p>Превосходный вишневый вкус подойдет, как любителям сладкого, так и тем, кто предпочитает нейтральный вкус изотоника.</p>
        </div>
        <div class="left bottom-margin-50">
          <h3>Супер восстановление</h3>
          <p>Выпейте после тренировки 100-150 мл изотоника, и ваше восстановление пройдет намного быстрее.</p>
        </div>
        <div class="right bottom-margin-50">
          <h3>Витаминый заряд</h3>
          <p>Витамины и минералы, обеспечивают оптимальный водно-солевой баланс во время физической активности.</p>
        </div>
        <a class="button" href="#top">Подробнее</a>
      </div>
   </div>
   <div class="contacts" id="contacts_link">
      <div class="inner">
      <h2>Контакты</h2>
      <div class="left">
        <h3>Телефоны</h3>
        <p>+375 29 <span>756 83 94</span></p>
        <p>+375 44 <span>534 38 31</span></p>
        <em> <a href="mailto:info@arena-energy.by">info@arena-energy.by</a></em>
        <a href="#top"><img src="images/arena-logofooter.png"></a>
      </div>
      <div class="right">  
      <h3>Остались вопросы, напишите нам</h3>
      <div id="result2"></div>
      <div id="FormBox2">
        <form id="form-contact" action="php/form_contact.php" method="post">
            <div class="input"><input type="text" name="name" placeholder="Имя..." required></div>
            <div class="input"><input type="mail" name="email" placeholder="email..." required></div>
            <textarea name="message" placeholder="Комментарий..."></textarea>
            <input class="submit" type="submit" name="submit" value="ОТПРАВИТЬ">
         </form>
      </div>
     </div>
    </div>
   </div>
  <footer>
    <div class="inner">
    <p> По вопросам приобретения углеводных гелей и изотонического напитка «Арена Нон-Стоп» обращаться по телефонам: +375 29 756 83 94 (МТС), +375 44 534 38 31 (Velcom), либо по электронной почте info@arena-energy.by<br>Продажи данного вида продукции вне торгового объекта не осуществляются.
    <p class="font-size-12px">©2017 Все права защищены. Разработка сайта — Гудимчик Алексей</p>
    </div>
  </footer>
</div>
</body>
</html>